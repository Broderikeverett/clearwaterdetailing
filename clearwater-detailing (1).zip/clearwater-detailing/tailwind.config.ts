import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        abyss:   "#04090f",
        deep:    "#070e1c",
        navy:    "#0a1628",
        marine:  "#0f2040",
        ocean:   "#1a3d6b",
        crystal: "#38b2d4",
        mist:    "#7dd3ea",
        platinum:"#b8ccd8",
        silk:    "#e8f0f6",
        gold:    "#c9a84c",
        "gold-l":"#e8c97a",
      },
      fontFamily: {
        display: ["var(--font-display)", "Georgia", "serif"],
        body:    ["var(--font-body)", "system-ui", "sans-serif"],
      },
      animation: {
        "shine": "shine 3s ease-in-out infinite",
        "float": "float 6s ease-in-out infinite",
        "ripple":"ripple 4s ease-in-out infinite",
        "glow":  "glow 3s ease-in-out infinite alternate",
      },
      keyframes: {
        shine: {
          "0%":   { backgroundPosition: "-200% center" },
          "100%": { backgroundPosition: "200% center" },
        },
        float: {
          "0%,100%": { transform: "translateY(0px)" },
          "50%":     { transform: "translateY(-12px)" },
        },
        ripple: {
          "0%,100%": { transform: "scale(1)", opacity: "0.3" },
          "50%":     { transform: "scale(1.15)", opacity: "0.6" },
        },
        glow: {
          "0%":   { textShadow: "0 0 20px rgba(56,178,212,0.3)" },
          "100%": { textShadow: "0 0 60px rgba(56,178,212,0.8)" },
        },
      },
    },
  },
  plugins: [],
};
export default config;
