import Link from "next/link";
export default function NotFound() {
  return (
    <div className="min-h-screen bg-abyss flex items-center justify-center text-center px-6">
      <div>
        <div className="font-display text-9xl text-crystal/20 font-light">404</div>
        <div className="font-display text-2xl text-silk font-light mt-4">Page Not Found</div>
        <Link href="/" className="inline-block mt-8 text-xs tracking-widest uppercase border border-crystal/30 text-crystal px-6 py-3 hover:bg-crystal/10 transition-all">
          Return Home
        </Link>
      </div>
    </div>
  );
}
