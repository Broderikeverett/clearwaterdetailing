import { NextRequest, NextResponse } from "next/server";
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY!);

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, phone, email, boatType, boatSize, package: pkg, message } = body;

    const html = `
<!DOCTYPE html>
<html>
<body style="font-family:sans-serif;background:#04090f;color:#e8f0f6;padding:40px;max-width:600px;margin:0 auto;">
  <div style="border:1px solid rgba(56,178,212,0.2);padding:32px;border-radius:2px;">
    <div style="font-size:24px;font-weight:300;color:#38b2d4;letter-spacing:4px;margin-bottom:4px;">CLEARWATER</div>
    <div style="font-size:11px;color:#7dd3ea;letter-spacing:3px;text-transform:uppercase;margin-bottom:32px;">New Quote Request</div>
    
    <table style="width:100%;border-collapse:collapse;">
      ${[
        ["Name", name],
        ["Email", email],
        ["Phone", phone || "Not provided"],
        ["Boat Type", boatType || "Not specified"],
        ["Boat Size", boatSize || "Not specified"],
        ["Package Interest", pkg || "Not specified"],
      ].map(([k, v]) => `
        <tr>
          <td style="padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.05);color:#7dd3ea;font-size:11px;text-transform:uppercase;letter-spacing:2px;width:140px;">${k}</td>
          <td style="padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.05);color:#b8ccd8;font-size:13px;">${v}</td>
        </tr>
      `).join("")}
    </table>

    ${message ? `
    <div style="margin-top:24px;">
      <div style="font-size:11px;color:#7dd3ea;letter-spacing:2px;text-transform:uppercase;margin-bottom:8px;">Notes</div>
      <div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);padding:16px;color:#b8ccd8;font-size:13px;line-height:1.6;">${message}</div>
    </div>
    ` : ""}

    <div style="margin-top:32px;padding-top:24px;border-top:1px solid rgba(56,178,212,0.15);font-size:11px;color:#38b2d480;">
      Reply directly to this email to respond to ${name}.
    </div>
  </div>
</body>
</html>`;

    // Send to business
    await resend.emails.send({
      from: "Clearwater Detailing <quotes@clearwaterdetailing.co>",
      to: process.env.CONTACT_EMAIL || "your@email.com",
      reply_to: email,
      subject: `New Quote Request — ${name} — ${boatSize || "?"} ${boatType || "Boat"}`,
      html,
    });

    // Send confirmation to customer
    await resend.emails.send({
      from: "Clearwater Detailing Co. <quotes@clearwaterdetailing.co>",
      to: email,
      subject: "We received your quote request",
      html: `
<!DOCTYPE html>
<html>
<body style="font-family:sans-serif;background:#04090f;color:#e8f0f6;padding:40px;max-width:600px;margin:0 auto;">
  <div style="border:1px solid rgba(56,178,212,0.2);padding:40px;border-radius:2px;">
    <div style="font-size:24px;font-weight:300;color:#38b2d4;letter-spacing:4px;margin-bottom:4px;">CLEARWATER</div>
    <div style="font-size:11px;color:#7dd3ea;letter-spacing:3px;text-transform:uppercase;margin-bottom:32px;">Detailing Co.</div>
    <h2 style="font-weight:300;font-size:28px;color:#e8f0f6;margin:0 0 8px;">Thank you, ${name}.</h2>
    <p style="color:#b8ccd8;font-size:14px;line-height:1.7;margin:16px 0 24px;">
      We've received your quote request and will review the details of your vessel carefully.
      You'll hear from us within <strong style="color:#38b2d4;">24 hours</strong> with a tailored quote.
    </p>
    <div style="background:rgba(56,178,212,0.05);border:1px solid rgba(56,178,212,0.15);padding:20px;margin:24px 0;">
      <div style="font-size:11px;color:#7dd3ea;letter-spacing:2px;text-transform:uppercase;margin-bottom:12px;">Your Request Summary</div>
      <div style="color:#b8ccd8;font-size:13px;line-height:2;">
        ${boatSize ? `Boat Size: ${boatSize}<br/>` : ""}
        ${boatType ? `Boat Type: ${boatType}<br/>` : ""}
        ${pkg ? `Package Interest: ${pkg}` : ""}
      </div>
    </div>
    <p style="color:#7dd3ea;font-size:13px;font-style:italic;">&ldquo;See the difference.&rdquo;</p>
    <p style="color:#b8ccd8;font-size:13px;margin-top:32px;">— The Clearwater Team</p>
  </div>
</body>
</html>`,
    });

    return NextResponse.json({ success: true });
  } catch (err: any) {
    console.error("Quote email error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
