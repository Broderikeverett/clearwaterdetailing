"use client";
import { useEffect, useRef } from "react";

export default function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    let t = 0;
    let animId: number;

    function draw() {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (let i = 0; i < 5; i++) {
        const x = canvas.width * (0.1 + i * 0.22 + Math.sin(t * 0.3 + i) * 0.05);
        const y = canvas.height * (0.3 + Math.sin(t * 0.2 + i * 1.2) * 0.15);
        const r = 200 + i * 80;
        const grad = ctx.createRadialGradient(x, y, 0, x, y, r);
        grad.addColorStop(0, `rgba(56,178,212,${0.04 + i * 0.01})`);
        grad.addColorStop(1, "transparent");
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }
      t += 0.01;
      animId = requestAnimationFrame(draw);
    }
    draw();

    const resize = () => {
      if (!canvas) return;
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", resize);
    return () => { cancelAnimationFrame(animId); window.removeEventListener("resize", resize); };
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Deep ocean gradient background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#020710] via-[#07102a] to-[#04090f]" />

      {/* Animated water caustics */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />

      {/* Horizon light ray */}
      <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-[#0a2040]/30" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-crystal/20 to-transparent" />

      {/* Floating particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(8)].map((_, i) => (
          <div key={i}
            className="absolute w-1 h-1 rounded-full bg-crystal/20"
            style={{
              left: `${10 + i * 12}%`,
              top: `${20 + (i % 3) * 25}%`,
              animation: `float ${4 + i * 0.5}s ease-in-out infinite`,
              animationDelay: `${i * 0.7}s`,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
        {/* Eyebrow */}
        <div className="flex items-center justify-center gap-4 mb-8">
          <div className="h-px w-12 bg-gradient-to-r from-transparent to-crystal/50" />
          <span className="text-crystal text-xs tracking-[0.3em] uppercase font-body font-light">
            Marine Detailing & Restoration
          </span>
          <div className="h-px w-12 bg-gradient-to-l from-transparent to-crystal/50" />
        </div>

        {/* Main headline */}
        <h1 className="font-display text-6xl md:text-8xl lg:text-9xl font-light text-silk leading-none mb-6">
          Premium Boat<br />
          <span className="italic text-crystal">Detailing</span>
          <span className="text-platinum/40"> &</span>
          <br />
          <span className="font-normal">Restoration</span>
        </h1>

        <div className="wave-line mb-8" />

        <p className="text-platinum/60 text-base md:text-lg font-body font-light max-w-2xl mx-auto leading-relaxed mb-12">
          Professional marine detailing, oxidation removal, and interior restoration 
          designed to keep your boat looking showroom ready.
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a href="#packages"
            className="gloss group relative px-8 py-4 bg-crystal text-abyss text-xs tracking-[0.2em] uppercase font-body font-medium hover:bg-mist transition-all duration-300 min-w-[180px]">
            View Packages
          </a>
          <a href="#contact"
            className="gloss px-8 py-4 border border-crystal/30 text-crystal text-xs tracking-[0.2em] uppercase font-body font-light hover:bg-crystal/10 transition-all duration-300 min-w-[180px]">
            Get A Quote
          </a>
        </div>

        {/* Scroll indicator */}
        <div className="mt-20 flex flex-col items-center gap-2 text-platinum/30">
          <span className="text-[10px] tracking-[0.3em] uppercase">Scroll</span>
          <div className="w-px h-12 bg-gradient-to-b from-platinum/30 to-transparent animate-pulse" />
        </div>
      </div>
    </section>
  );
}
