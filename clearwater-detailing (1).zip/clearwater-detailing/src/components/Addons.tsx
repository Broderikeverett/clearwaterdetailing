"use client";
import { useState } from "react";

const addons = [
  { name: "Water Spot Removal", price: "$75–$150+", icon: "💦", desc: "Eliminate stubborn mineral deposits and cloudiness from gelcoat and glass." },
  { name: "Carpet Extraction", price: "$90+", icon: "🧹", desc: "Deep extraction cleaning for heavily soiled or wet marine carpets." },
  { name: "Seat Stain Removal", price: "$40+", icon: "🪑", desc: "Targeted treatment for tough stains on vinyl seating and upholstery." },
  { name: "Trailer Polish", price: "$90–$220+", icon: "🚗", desc: "Full trailer detail including frame polish and protective coating." },
  { name: "Ceramic Spray Coating", price: "$150+", icon: "🛡️", desc: "Premium hydrophobic protection that repels water, salt, and UV damage." },
  { name: "Heavy Oxidation Upgrade", price: "$150+", icon: "⚡", desc: "Advanced compound treatment for severely oxidized and chalky hulls." },
];

export default function Addons() {
  const [selected, setSelected] = useState<number[]>([]);

  const toggle = (i: number) =>
    setSelected((prev) => prev.includes(i) ? prev.filter((x) => x !== i) : [...prev, i]);

  return (
    <section id="addons" className="py-32 px-6 water-bg">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="text-crystal text-xs tracking-[0.3em] uppercase mb-4">Customize</div>
          <h2 className="font-display text-5xl md:text-6xl font-light text-silk mb-4">
            Add-On <span className="italic">Services</span>
          </h2>
          <div className="wave-line" />
          <p className="text-platinum/50 font-body font-light mt-6 max-w-xl mx-auto">
            Stack any of these onto your chosen package for a fully tailored detail.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {addons.map((a, i) => {
            const active = selected.includes(i);
            return (
              <div
                key={i}
                onClick={() => toggle(i)}
                className={`gloss cursor-pointer p-6 transition-all duration-300 relative
                  ${active
                    ? "border border-crystal/50 bg-crystal/5"
                    : "glass border-white/5 hover:border-crystal/20"
                  }`}
              >
                {/* Selected indicator */}
                {active && (
                  <div className="absolute top-4 right-4 w-5 h-5 bg-crystal flex items-center justify-center">
                    <span className="text-abyss text-[10px]">✓</span>
                  </div>
                )}

                <div className="text-2xl mb-4">{a.icon}</div>
                <div className="font-display text-xl text-silk font-light mb-1">{a.name}</div>
                <div className={`text-sm font-body font-medium mb-3 ${active ? "text-crystal" : "text-crystal/60"}`}>
                  {a.price}
                </div>
                <p className="text-platinum/50 text-sm font-body font-light leading-relaxed">{a.desc}</p>
              </div>
            );
          })}
        </div>

        {selected.length > 0 && (
          <div className="mt-8 text-center">
            <p className="text-crystal text-sm font-body mb-4">
              {selected.length} add-on{selected.length > 1 ? "s" : ""} selected — mention these when requesting your quote.
            </p>
            <a href="#contact"
              className="inline-block px-8 py-4 bg-crystal text-abyss text-xs tracking-[0.2em] uppercase font-body font-medium hover:bg-mist transition-all duration-300">
              Request Quote with Add-Ons
            </a>
          </div>
        )}
      </div>
    </section>
  );
}
