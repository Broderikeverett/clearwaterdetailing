"use client";
import { useState } from "react";

const pairs = [
  { label: "Oxidized Hull → Restored Shine", category: "Exterior" },
  { label: "Faded Vinyl → Conditioned Seats", category: "Interior" },
  { label: "Corroded Metal → Polished Finish", category: "Hardware" },
  { label: "Stained Carpet → Extracted Clean", category: "Interior" },
  { label: "Water Spots → Crystal Clear", category: "Glass" },
  { label: "Chalky Gel Coat → High Gloss", category: "Exterior" },
];

function BeforeAfterCard({ pair, index }: { pair: typeof pairs[0]; index: number }) {
  const [pos, setPos] = useState(50);
  const [dragging, setDragging] = useState(false);

  const gradients = [
    ["from-[#1a2a1a] via-[#2d3d2d]", "from-[#0a1628] via-[#1a3d6b]"],
    ["from-[#2a1a0a] via-[#3d2a1a]", "from-[#0a1628] via-[#0f2040]"],
    ["from-[#1a1a2a] via-[#2a2a3d]", "from-[#0a1020] via-[#1a2040]"],
  ];
  const [before, after] = gradients[index % gradients.length];

  const handleMove = (clientX: number, rect: DOMRect) => {
    const x = ((clientX - rect.left) / rect.width) * 100;
    setPos(Math.max(5, Math.min(95, x)));
  };

  return (
    <div className="glass overflow-hidden group">
      {/* Slider */}
      <div className="relative h-52 cursor-ew-resize select-none"
        onMouseMove={(e) => dragging && handleMove(e.clientX, e.currentTarget.getBoundingClientRect())}
        onMouseDown={() => setDragging(true)}
        onMouseUp={() => setDragging(false)}
        onMouseLeave={() => setDragging(false)}
        onTouchMove={(e) => handleMove(e.touches[0].clientX, e.currentTarget.getBoundingClientRect())}
      >
        {/* Before */}
        <div className={`absolute inset-0 bg-gradient-to-br ${before} to-[#1a1a1a] flex items-center justify-center`}>
          <span className="text-white/20 text-xs tracking-widest uppercase font-body">Before</span>
          {/* Grime texture simulation */}
          <div className="absolute inset-0 opacity-20"
            style={{ backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 2px, rgba(0,0,0,0.1) 2px, rgba(0,0,0,0.1) 4px)" }} />
        </div>

        {/* After */}
        <div className={`absolute inset-0 bg-gradient-to-br ${after} to-abyss flex items-center justify-center overflow-hidden`}
          style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
          <span className="text-crystal/40 text-xs tracking-widest uppercase font-body">After</span>
          {/* Gloss simulation */}
          <div className="absolute inset-0 opacity-30"
            style={{ background: "linear-gradient(135deg, rgba(56,178,212,0.2) 0%, transparent 50%, rgba(56,178,212,0.1) 100%)" }} />
        </div>

        {/* Slider handle */}
        <div className="absolute top-0 bottom-0 w-0.5 bg-white/60 pointer-events-none"
          style={{ left: `${pos}%` }}>
          <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-white/90 border-2 border-crystal flex items-center justify-center shadow-lg">
            <span className="text-[8px] text-abyss">◁▷</span>
          </div>
        </div>
      </div>

      {/* Label */}
      <div className="p-5 flex items-center justify-between">
        <div>
          <div className="text-xs text-crystal tracking-widest uppercase font-body mb-1">{pair.category}</div>
          <div className="font-display text-base text-silk/80 font-light">{pair.label}</div>
        </div>
        <div className="text-crystal/30 text-xs">Drag ◁▷</div>
      </div>
    </div>
  );
}

export default function Gallery() {
  return (
    <section id="gallery" className="py-32 px-6 bg-navy">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="text-crystal text-xs tracking-[0.3em] uppercase mb-4">Results</div>
          <h2 className="font-display text-5xl md:text-6xl font-light text-silk mb-4">
            Before & <span className="italic">After</span>
          </h2>
          <div className="wave-line" />
          <p className="text-platinum/50 font-body font-light mt-6 max-w-xl mx-auto">
            Drag the slider to reveal the transformation. Every vessel tells a story — we write the next chapter.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {pairs.map((p, i) => <BeforeAfterCard key={i} pair={p} index={i} />)}
        </div>
      </div>
    </section>
  );
}
