"use client";
import { useState } from "react";

const packages = ["Wash & Protect ($300+)", "Interior Revival ($450+)", "Oxidation & Shine ($700+)", "Full Restoration ($1,000+)", "Not Sure Yet"];
const boatSizes = ["Under 20 ft", "20–25 ft", "26–30 ft", "31–36 ft", "37–40 ft", "40+ ft"];
const boatTypes = ["Center Console", "Bowrider", "Cabin Cruiser", "Pontoon", "Sport Yacht", "Fishing Boat", "Sailboat", "Other"];

export default function Contact() {
  const [form, setForm] = useState({
    name: "", phone: "", email: "",
    boatType: "", boatSize: "", package: "", message: "",
  });
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("sending");
    try {
      const res = await fetch("/api/quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      setStatus(data.success ? "sent" : "error");
    } catch {
      setStatus("error");
    }
  };

  const field = "w-full bg-transparent border border-white/10 text-silk text-sm font-body font-light px-4 py-3.5 focus:outline-none focus:border-crystal/50 transition-colors placeholder:text-platinum/25";
  const label = "text-xs tracking-widest uppercase text-platinum/40 font-body mb-2 block";

  return (
    <section id="contact" className="py-32 px-6 bg-deep">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-5 gap-16 items-start">

          {/* Left info */}
          <div className="md:col-span-2">
            <div className="text-crystal text-xs tracking-[0.3em] uppercase mb-4">Get In Touch</div>
            <h2 className="font-display text-5xl font-light text-silk mb-4 leading-tight">
              Request<br />
              <span className="italic">A Quote</span>
            </h2>
            <div className="wave-line mb-8" style={{ margin: "0 0 32px 0" }} />
            <p className="text-platinum/50 font-body font-light text-sm leading-relaxed mb-10">
              Fill out the form and we&apos;ll get back to you within 24 hours with a tailored 
              quote for your vessel. No obligation — just honest pricing.
            </p>

            <div className="space-y-6">
              {[
                { icon: "📍", label: "Service Area", value: "Tampa Bay & Surrounding Areas" },
                { icon: "📞", label: "Phone", value: "Available on Request" },
                { icon: "⏱", label: "Response Time", value: "Within 24 Hours" },
              ].map((item, i) => (
                <div key={i} className="flex gap-4 items-start">
                  <span className="text-xl mt-0.5">{item.icon}</span>
                  <div>
                    <div className="text-xs tracking-widest uppercase text-crystal/60 font-body">{item.label}</div>
                    <div className="text-platinum/70 font-body font-light text-sm mt-0.5">{item.value}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Form */}
          <div className="md:col-span-3">
            {status === "sent" ? (
              <div className="glass border border-crystal/20 p-12 text-center">
                <div className="text-crystal text-4xl mb-4">⚓</div>
                <h3 className="font-display text-3xl text-silk font-light mb-3">Quote Requested</h3>
                <div className="wave-line" />
                <p className="text-platinum/60 font-body font-light text-sm mt-6">
                  Thank you, {form.name}. We&apos;ll review your details and reach out within 24 hours with a tailored quote.
                </p>
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className={label}>Full Name</label>
                    <input required placeholder="Your name" value={form.name}
                      onChange={(e) => set("name", e.target.value)} className={field} />
                  </div>
                  <div>
                    <label className={label}>Phone</label>
                    <input placeholder="(000) 000-0000" value={form.phone}
                      onChange={(e) => set("phone", e.target.value)} className={field} />
                  </div>
                </div>

                <div>
                  <label className={label}>Email</label>
                  <input required type="email" placeholder="your@email.com" value={form.email}
                    onChange={(e) => set("email", e.target.value)} className={field} />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className={label}>Boat Type</label>
                    <select value={form.boatType} onChange={(e) => set("boatType", e.target.value)}
                      className={field + " bg-deep"}>
                      <option value="">Select type</option>
                      {boatTypes.map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className={label}>Boat Size</label>
                    <select value={form.boatSize} onChange={(e) => set("boatSize", e.target.value)}
                      className={field + " bg-deep"}>
                      <option value="">Select size</option>
                      {boatSizes.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                </div>

                <div>
                  <label className={label}>Desired Package</label>
                  <select value={form.package} onChange={(e) => set("package", e.target.value)}
                    className={field + " bg-deep"}>
                    <option value="">Select package</option>
                    {packages.map((p) => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>

                <div>
                  <label className={label}>Additional Notes</label>
                  <textarea rows={4} placeholder="Tell us about your boat's condition, any specific concerns, or questions..."
                    value={form.message} onChange={(e) => set("message", e.target.value)}
                    className={field + " resize-none"} />
                </div>

                {status === "error" && (
                  <p className="text-red-400/80 text-sm font-body">Something went wrong. Please try again or contact us directly.</p>
                )}

                <button type="submit" disabled={status === "sending"}
                  className="gloss w-full bg-crystal text-abyss py-4 text-xs tracking-[0.3em] uppercase font-body font-medium hover:bg-mist transition-all duration-300 disabled:opacity-50">
                  {status === "sending" ? "Sending Request..." : "Request A Quote"}
                </button>

                <p className="text-platinum/25 text-xs font-body text-center">
                  No obligation. We respond within 24 hours.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
