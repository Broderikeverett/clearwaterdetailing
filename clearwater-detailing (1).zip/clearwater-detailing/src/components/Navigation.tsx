"use client";
import { useState, useEffect } from "react";

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const links = ["About", "Packages", "Add-Ons", "Gallery", "Testimonials", "Contact"];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
      scrolled ? "py-3 bg-abyss/90 backdrop-blur-xl border-b border-white/5" : "py-6"
    }`}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <div className="font-display font-light text-2xl tracking-widest text-silk">
          CLEARWATER<span className="text-crystal">.</span>
        </div>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <a key={l} href={`#${l.toLowerCase().replace("-","")}`}
              className="text-xs tracking-widest uppercase text-platinum/60 hover:text-crystal transition-colors duration-300">
              {l}
            </a>
          ))}
          <a href="#contact"
            className="text-xs tracking-widest uppercase bg-crystal/10 hover:bg-crystal/20 border border-crystal/30 text-crystal px-5 py-2.5 transition-all duration-300">
            Get A Quote
          </a>
        </div>

        {/* Mobile menu button */}
        <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden text-platinum">
          <div className={`w-6 h-0.5 bg-current transition-all ${menuOpen ? "rotate-45 translate-y-1.5" : ""}`} />
          <div className={`w-6 h-0.5 bg-current mt-1.5 transition-all ${menuOpen ? "opacity-0" : ""}`} />
          <div className={`w-6 h-0.5 bg-current mt-1.5 transition-all ${menuOpen ? "-rotate-45 -translate-y-1.5" : ""}`} />
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden bg-abyss/95 backdrop-blur-xl border-t border-white/5 px-6 py-6">
          {links.map((l) => (
            <a key={l} href={`#${l.toLowerCase().replace("-","")}`}
              onClick={() => setMenuOpen(false)}
              className="block text-sm tracking-widest uppercase text-platinum/60 hover:text-crystal py-3 border-b border-white/5 transition-colors">
              {l}
            </a>
          ))}
          <a href="#contact" onClick={() => setMenuOpen(false)}
            className="block mt-4 text-center text-xs tracking-widest uppercase bg-crystal/10 border border-crystal/30 text-crystal px-5 py-3">
            Get A Quote
          </a>
        </div>
      )}
    </nav>
  );
}
