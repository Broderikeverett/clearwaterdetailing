"use client";

const reviews = [
  {
    name: "Captain Michael T.",
    vessel: "32' Sea Ray Sundancer",
    text: "Clearwater brought my boat back to life. The oxidation on my hull had me convinced I needed a new paint job — they removed it completely in one session. Absolutely showroom finish.",
    stars: 5,
    location: "Tampa, FL",
  },
  {
    name: "Sarah & James W.",
    vessel: "26' Chaparral Sunesta",
    text: "We were embarrassed by the state of our vinyl seats. After the Interior Revival package they look brand new — better than when we bought the boat. We'll never use anyone else.",
    stars: 5,
    location: "Clearwater, FL",
  },
  {
    name: "Robert K.",
    vessel: "40' Bertram Sportfish",
    text: "I've had boats detailed before but nothing like this. The attention to detail on the Full Restoration package is unreal. Every surface, every compartment, every chrome fitting — perfect.",
    stars: 5,
    location: "St. Pete Beach, FL",
  },
  {
    name: "Donna L.",
    vessel: "22' Bayliner Element",
    text: "Quick, professional, and the results exceeded every expectation. My starter boat now looks like something out of a magazine. Highly recommend the ceramic coating add-on.",
    stars: 5,
    location: "Dunedin, FL",
  },
  {
    name: "Marcus E.",
    vessel: "38' Tiara Sport",
    text: "The team showed up on time, worked meticulously, and left the marina slip cleaner than they found it. Professionalism top to bottom — this is what premium service looks like.",
    stars: 5,
    location: "St. Petersburg, FL",
  },
  {
    name: "Linda & Tom B.",
    vessel: "28' Cobalt A28",
    text: "We&apos;ve used Clearwater three times now and the consistency is remarkable. They treat your boat like it&apos;s their own. The Wash & Protect package is perfect for our monthly maintenance.",
    stars: 5,
    location: "Treasure Island, FL",
  },
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-32 px-6 water-bg">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="text-crystal text-xs tracking-[0.3em] uppercase mb-4">Reviews</div>
          <h2 className="font-display text-5xl md:text-6xl font-light text-silk mb-4">
            What Our <span className="italic">Clients Say</span>
          </h2>
          <div className="wave-line" />
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {reviews.map((r, i) => (
            <div key={i} className="gloss glass p-7 flex flex-col gap-4 hover:-translate-y-1 transition-all duration-300">
              {/* Stars */}
              <div className="flex gap-1">
                {[...Array(r.stars)].map((_, j) => (
                  <span key={j} className="text-gold text-sm">★</span>
                ))}
              </div>

              {/* Quote */}
              <p className="text-platinum/70 font-body font-light text-sm leading-relaxed flex-1">
                &ldquo;{r.text}&rdquo;
              </p>

              {/* Author */}
              <div className="pt-4 border-t border-white/5">
                <div className="font-display text-silk text-lg font-light">{r.name}</div>
                <div className="text-crystal/60 text-xs tracking-wider font-body mt-0.5">{r.vessel}</div>
                <div className="text-platinum/30 text-xs font-body mt-0.5">{r.location}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
