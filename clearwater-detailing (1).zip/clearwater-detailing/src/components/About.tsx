"use client";
import { useEffect, useRef, useState } from "react";

const stats = [
  { value: "500+", label: "Boats Detailed" },
  { value: "8+", label: "Years Experience" },
  { value: "100%", label: "Satisfaction Rate" },
  { value: "5★", label: "Average Rating" },
];

export default function About() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true); }, { threshold: 0.2 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  return (
    <section id="about" className="py-32 px-6 water-bg" ref={ref}>
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-20 items-center">

          {/* Left — visual */}
          <div className={`transition-all duration-1000 ${visible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"}`}>
            <div className="relative">
              {/* Main visual block */}
              <div className="relative h-[500px] glass overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-ocean/40 via-marine/20 to-abyss" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="font-display text-[120px] font-light text-crystal/10 leading-none select-none">C</div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center px-8">
                        <div className="text-crystal text-4xl mb-4">⚓</div>
                        <div className="font-display text-3xl text-silk font-light italic">
                          &ldquo;Every detail matters&rdquo;
                        </div>
                        <div className="wave-line mt-4" />
                        <p className="text-platinum/50 text-sm mt-4 font-body">
                          Clearwater Detailing Co.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                {/* Corner accents */}
                <div className="absolute top-4 left-4 w-8 h-8 border-t border-l border-crystal/30" />
                <div className="absolute bottom-4 right-4 w-8 h-8 border-b border-r border-crystal/30" />
              </div>
              {/* Floating stat */}
              <div className="absolute -bottom-6 -right-6 glass p-6 border border-crystal/20">
                <div className="font-display text-4xl text-crystal font-light">8+</div>
                <div className="text-platinum/50 text-xs tracking-widest uppercase mt-1">Years on the Water</div>
              </div>
            </div>
          </div>

          {/* Right — text */}
          <div className={`transition-all duration-1000 delay-200 ${visible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"}`}>
            <div className="text-crystal text-xs tracking-[0.3em] uppercase mb-4">Our Story</div>
            <h2 className="font-display text-5xl md:text-6xl font-light text-silk mb-6 leading-tight">
              Passion for<br />
              <span className="italic text-crystal">the perfect finish</span>
            </h2>
            <div className="wave-line mb-8" style={{ margin: "0 0 32px 0" }} />

            <div className="space-y-5 text-platinum/60 font-body font-light leading-relaxed">
              <p>
                We believe your boat deserves the same care and precision as the finest automobiles. 
                Every detail — from the oxidized gel coat to the mildewed upholstery — tells the story 
                of time on the water. We&apos;re here to restore that story.
              </p>
              <p>
                Using only premium marine-grade products, our team approaches every vessel with 
                meticulous attention to detail. We protect your investment, restore its shine, 
                and return it to you in better condition than you imagined possible.
              </p>
              <p>
                Your satisfaction isn&apos;t just our goal — it&apos;s our guarantee. We don&apos;t 
                consider a job done until you do.
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4 mt-10">
              {stats.map((s, i) => (
                <div key={i} className="glass p-5 border-l-2 border-crystal/30">
                  <div className="font-display text-3xl text-crystal font-light">{s.value}</div>
                  <div className="text-platinum/40 text-xs tracking-wider uppercase mt-1">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
