export default function Footer() {
  return (
    <footer className="py-16 px-6 bg-abyss border-t border-white/5">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div>
            <div className="font-display text-2xl font-light tracking-widest text-silk">
              CLEARWATER<span className="text-crystal">.</span>
            </div>
            <div className="text-platinum/30 text-xs tracking-widest uppercase mt-1 font-body">
              Premium Marine Detailing
            </div>
          </div>

          <div className="flex gap-8 text-xs tracking-widest uppercase text-platinum/30 font-body">
            {["About", "Packages", "Add-Ons", "Gallery", "Contact"].map((l) => (
              <a key={l} href={`#${l.toLowerCase()}`}
                className="hover:text-crystal transition-colors">{l}</a>
            ))}
          </div>

          <div className="text-platinum/20 text-xs font-body text-center md:text-right">
            <div>&copy; {new Date().getFullYear()} Clearwater Detailing Co.</div>
            <div className="mt-1 italic text-platinum/15 font-display">&ldquo;See the difference.&rdquo;</div>
          </div>
        </div>
      </div>
    </footer>
  );
}
