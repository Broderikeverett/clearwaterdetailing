"use client";
import { useState } from "react";

const packages = [
  {
    name: "Wash & Protect",
    price: "From $300",
    icon: "💧",
    tier: 1,
    features: [
      "Hand wash & foam cannon pre-soak",
      "Wheels and trailer rinse",
      "Vinyl wipe down",
      "Interior vacuum",
      "Windows cleaned inside & out",
      "Spray wax / protectant",
      "Quick dry and towel finish",
    ],
    cta: "Book This Package",
    accent: "crystal",
  },
  {
    name: "Interior Revival",
    price: "From $450",
    icon: "✨",
    tier: 2,
    features: [
      "Everything in Wash & Protect",
      "Deep vinyl cleaning & treatment",
      "Mildew / mold treatment",
      "Carpet shampoo & extraction",
      "Seat conditioning & protectant",
      "Storage compartment cleaning",
      "Cupholder & detail brush cleaning",
      "Non-slip floor scrubbing",
    ],
    cta: "Book This Package",
    accent: "crystal",
  },
  {
    name: "Oxidation & Shine",
    price: "From $700",
    icon: "🔆",
    tier: 3,
    popular: true,
    features: [
      "Everything above",
      "Compound oxidation removal",
      "Machine polish",
      "Gel coat restoration",
      "Heavy water spot removal",
      "High gloss finish",
      "Professional sealant & wax",
    ],
    cta: "Most Popular — Book Now",
    accent: "crystal",
  },
  {
    name: "Full Restoration",
    price: "From $1,000+",
    sub: "Price varies by condition & size",
    icon: "⚓",
    tier: 4,
    elite: true,
    features: [
      "Full exterior wash & detail",
      "Complete interior deep clean",
      "Carpet extraction",
      "Vinyl restoration",
      "Compound + machine polish",
      "Professional sealant & wax",
      "Full trailer clean & polish",
      "Metal polishing",
      "Engine bay wipe-down",
      "Final touch & detail pass",
    ],
    cta: "Request Elite Service",
    accent: "gold",
  },
];

export default function Packages() {
  const [hovered, setHovered] = useState<number | null>(null);

  return (
    <section id="packages" className="py-32 px-6 bg-deep">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-20">
          <div className="text-crystal text-xs tracking-[0.3em] uppercase mb-4">Pricing</div>
          <h2 className="font-display text-5xl md:text-7xl font-light text-silk mb-4">
            Our <span className="italic">Packages</span>
          </h2>
          <div className="wave-line" />
          <p className="text-platinum/50 font-body font-light mt-6 max-w-xl mx-auto">
            From a quick refresh to a complete transformation — choose the level of care your vessel deserves.
          </p>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-6">
          {packages.map((pkg, i) => (
            <div
              key={i}
              onMouseEnter={() => setHovered(i)}
              onMouseLeave={() => setHovered(null)}
              className={`gloss relative flex flex-col transition-all duration-500 cursor-pointer
                ${pkg.elite
                  ? "border border-gold/30 bg-gradient-to-b from-[#1a1200] to-[#0a0800]"
                  : pkg.popular
                  ? "border border-crystal/40 bg-gradient-to-b from-ocean/30 to-marine/20"
                  : "glass border-white/5"}
                ${hovered === i ? "-translate-y-2 shadow-2xl shadow-crystal/10" : ""}
              `}
            >
              {/* Popular badge */}
              {pkg.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-crystal text-abyss text-[10px] tracking-widest uppercase px-4 py-1 font-body font-medium">
                  Most Popular
                </div>
              )}
              {pkg.elite && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gold text-abyss text-[10px] tracking-widest uppercase px-4 py-1 font-body font-medium">
                  Elite
                </div>
              )}

              <div className={`p-8 flex-1 ${pkg.popular || pkg.elite ? "pt-10" : ""}`}>
                {/* Icon */}
                <div className="text-3xl mb-6">{pkg.icon}</div>

                {/* Name + price */}
                <div className={`font-display text-2xl font-light mb-1 ${pkg.elite ? "gold-text" : "text-silk"}`}>
                  {pkg.name}
                </div>
                <div className={`text-3xl font-display font-light mb-1 ${pkg.elite ? "gold-text" : "text-crystal"}`}>
                  {pkg.price}
                </div>
                {pkg.sub && (
                  <div className="text-platinum/40 text-xs font-body mb-6">{pkg.sub}</div>
                )}

                <div className={`h-px mb-6 ${pkg.elite ? "bg-gold/20" : "bg-crystal/15"}`} />

                {/* Features */}
                <ul className="space-y-3">
                  {pkg.features.map((f, j) => (
                    <li key={j} className="flex items-start gap-3 text-sm font-body text-platinum/60">
                      <span className={`mt-0.5 text-xs ${pkg.elite ? "text-gold" : "text-crystal"}`}>◆</span>
                      {f}
                    </li>
                  ))}
                </ul>
              </div>

              {/* CTA */}
              <div className="p-8 pt-0">
                <a href="#contact"
                  className={`block text-center text-xs tracking-[0.2em] uppercase py-4 transition-all duration-300
                    ${pkg.elite
                      ? "bg-gold/10 border border-gold/30 text-gold hover:bg-gold/20"
                      : pkg.popular
                      ? "bg-crystal text-abyss hover:bg-mist"
                      : "border border-crystal/20 text-crystal/70 hover:bg-crystal/10"
                    }`}>
                  {pkg.cta}
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
